package com.example.library;

public class Book {
    public String title;
    public String author;
    public String barcode;
    public boolean isCheckedOut;

    public Book(String title, String author, String barcode){
        if (title==null || title.isEmpty() || author==null || author.isEmpty() || barcode==null || barcode.isEmpty()){
            throw new IllegalArgumentException("Title, author, and barcode must not be null or empty.");
        }
        this.title=title;
        this.author=author;
        this.barcode=barcode;
        this.isCheckedOut=false;
    }

    public Book() {
        
    }

    public String getTitle() {
        return title;
    }

    public String getBarcode() {
        return barcode;
    }

    public boolean isCheckedOut() {
        return isCheckedOut;
    }

    public void setCheckedOut( boolean checkedOut ) {
        isCheckedOut = checkedOut;
    }

    @Override
    public String toString() {
        return "Book{" + "title='" + title + '\'' + ",author='" + author + '\'' + ",barcode='" + barcode + '\'' + ",isCheckedOut=" + isCheckedOut + '}';
    }
}